CELULAR CON PROPÓSITO — PÁGINA WEB

1. Abre index.html para probar la página.
2. La encuesta incluida es una demostración local: no envía respuestas a Internet.
3. Para que otras personas entren desde un QR, publica la carpeta en un servicio de hosting (por ejemplo GitHub Pages, Netlify o similar).
4. Copia la URL pública y genera un código QR con esa URL.
5. Si quieres recopilar respuestas reales de forma sencilla, puedes sustituir la encuesta por un Google Forms y poner su enlace detrás del botón/QR.

No se han inventado porcentajes de encuesta.
